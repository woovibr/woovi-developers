<?php

class Woovi_Pix_Block_Info extends Mage_Payment_Block_Info
{
  use Woovi_Pix_Trait_ExceptionMessenger;
  use Woovi_Pix_Trait_LogMessenger;

  protected function _construct()
  {
    parent::_construct();
    $this->setTemplate('woovi/pix/payment/info/woovi.phtml');
  }
}
