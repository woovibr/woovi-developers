<?php

class Woovi_Pix_Model_Sales_Order_Total_Invoice_Discount extends
  Mage_Sales_Model_Order_Invoice_Total_Abstract
{
  /**
   * Collect invoice total
   *
   * @param Mage_Sales_Model_Order_Invoice $invoice
   *
   * @return Woovi_Pix_Model_Sales_Order_Total_Invoice_Discount
   */
  public function collect(Mage_Sales_Model_Order_Invoice $invoice)
  {
    $invoice->setGiftbackDiscount(0);
    $invoice->setBaseGiftbackDiscount(0);
    $order = $invoice->getOrder();

    $giftbackDiscount = $order->getGiftbackDiscount();
    $baseGiftbackDiscount = $order->getGiftbackDiscount();

    $totalWooviDiscount = $giftbackDiscount > 0 ? $giftbackDiscount : 0;
    $baseTotalWooviDiscount =
      $baseGiftbackDiscount > 0 ? $baseGiftbackDiscount : 0;

    $invoice->setGiftbackDiscount(-$totalWooviDiscount);
    $invoice->setBaseGiftbackDiscount(-$baseTotalWooviDiscount);

    $invoice->setGrandTotal($invoice->getGrandTotal() - $totalWooviDiscount);

    $invoice->setBaseGrandTotal(
      $invoice->getBaseGrandTotal() - $baseTotalWooviDiscount
    );

    return $this;
  }
}
