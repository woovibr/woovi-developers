<?php

class Woovi_Pix_Block_Sales_Order_Discount extends Mage_Core_Block_Template
{
  /**
   * Initialize giftback discount totals
   *
   * @return Woovi_Pix_Block_Sales_Order_Discount
   */
  public function initTotals()
  {
    if ((float) $this->getOrder()->getBaseGiftbackDiscount()) {
      $source = $this->getSource();
      $value = $source->getGiftbackDiscount();
      $title = $this->__('Desconto Giftback');
      $this->getParentBlock()->addTotal(
        new Varien_Object([
          'code' => 'giftback_discount',
          'strong' => false,
          'label' => $title,
          'value' => -abs($value),
        ])
      );
    }

    return $this;
  }

  /**
   * Get order store object
   *
   * @return Mage_Sales_Model_Order
   */
  public function getOrder()
  {
    return $this->getParentBlock()->getOrder();
  }

  /**
   * Get totals source object
   *
   * @return Mage_Sales_Model_Order
   */
  public function getSource()
  {
    return $this->getParentBlock()->getSource();
  }
}
