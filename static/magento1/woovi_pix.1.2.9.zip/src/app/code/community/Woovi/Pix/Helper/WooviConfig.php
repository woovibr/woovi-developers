<?php

class Woovi_Pix_Helper_Config extends Mage_Core_Helper_Abstract
{
  public function getWooviApiUrl()
  {
    // production
    return 'https://api.woovi.com.br';
  }

  public function getWooviPluginUrlScript()
  {
    return 'https://plugin.woovi.com.br/v1/woovi.js';
  }
}
